#!/bin/bash
# 在服务器 /www/wwwroot/zuqiu/server 目录执行: bash deploy/restart-espn.sh
set -e
cd "$(dirname "$0")/.."
echo "========== 1. 检查文件 =========="
if [ ! -f src/espnClient.js ]; then
  echo "❌ 缺少 src/espnClient.js — 请上传 ESPN 新代码"
  exit 1
fi
echo "✓ espnClient.js 存在"

if ! grep -q "espnClient" src/index.js; then
  echo "❌ src/index.js 仍是旧版（未引用 espnClient）"
  exit 1
fi
echo "✓ index.js 已是 ESPN 版"

if [ -f src/footballData.js ]; then
  echo "⚠ 建议删除旧文件: rm src/footballData.js"
fi

echo ""
echo "========== 2. 重启 PM2 =========="
if pm2 describe zuqiu-api >/dev/null 2>&1; then
  pm2 restart zuqiu-api
else
  pm2 start ecosystem.config.cjs
fi
pm2 save

sleep 2
echo ""
echo "========== 3. 本地健康检查 =========="
HEALTH=$(curl -s http://127.0.0.1:3000/api/health)
echo "$HEALTH"
if echo "$HEALTH" | grep -q '"provider":"espn"'; then
  echo "✅ ESPN 后端已生效"
else
  echo "❌ 仍是旧后端！请确认 src/ 文件已覆盖后重试"
  pm2 logs zuqiu-api --lines 20 --nostream
  exit 1
fi
